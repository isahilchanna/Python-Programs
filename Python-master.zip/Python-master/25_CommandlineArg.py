import sys
# program_name = sys.argv[0]
print ("sys.argv is :", sys.argv)
# print ("program name is : ", program_name)
# l=[]
# l=sys.argv
# print l
# print l[0]
# print dir(sys)
# print (program_name)
# arguments = sys.argv[1:]
# print ("arguments are " ,arguments)
# count = len(arguments)
# print ("the number of parameters passed is :",count)
# print sys.argv

# print ("java "+sys.argv[1]+" "+ sys.argv[2])

s=sys.argv[1]
# print type(s)
# print sys.argv
# print (s)
print (s[::-1])
# s=sys.argv[1]

if s==s[::-1]:
	print ("pellindrome")
else:
	print ("not pellindrom")
	
# python .\25_CommandlineArg.py kayak.txt asdfadfadasdfasdfasdf asfdasdfad asdfasdfasdf asdfasdf
# fp=open(sys.argv[1],'w')
# for l in sys.argv[2:]:
# 	fp.write(l)

# fp.write(sys.argv[2])
# Assignment :
# Write all the program which we did till now in command line argument.
# a= int(sys.argv[2])
# b=int(sys.argv[3])
# def add(a,b):
#     return a+b
# x= add(a,b)
# print(x)
# print (add(3,4))


