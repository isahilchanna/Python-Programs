# High level
# Object oriented lan
# used for data science
# C++, java,C- Compiler based language
# Python- Interpreter based language
# C program execution

# Preprocessin
# Compilation
# assemble
# Linking
# Loadin
# execution
# a.out
# Java progrma execution
# intremediate fils are created
# Python
# Compiler
# Interpreter
 
# sublime editor/ pycharm
# Python version 2.7   3.6
# the main difference: in C, the data types of each variable are explicitly declared, 
# while in Python the types are dynamically inferred. 
# This means, for example, that we can assign any kind of data to any variable:
# 
# There are mutable and Immutable types of Pythons built in types Mutable built-in types
# List
# Sets
# Dictionaries
# Immutable built-in types
# Strings
# Tuples
# Numbers


# a=10
# b=10.0
# c="python"
# z="123"
# print "monica"
# print "hello"
# print "python"
# print "10"

# print 10.0
# print a
# print "error before"
#
#
# int a #//not resquired in python
#


# import quandl
# import pandas as pd

# df = quandl.get("WIKI/GOOGL")

# print(df.head())

# a=101#integer
# print a

# print a==10
# b=10.0 #float
# s="python123"
# x='python'
# s="123"

# print "hello"
# type
# 
print "priya"
# ctrl+ /
# print "hello world"

# print a
# a=10
# print a
# j=10.00
# print j
# s="python"
# print s
# print "python1"

# s1='python1'/
# s2='python1.0'
# print s2
# s3="123"
# print (s1)
# = assignment operator

# = RHS to LHS
# a = 10
# print a
# a = a+10+30+40+a
# print a
# b=10
# a=b+40+a# a=10+40+100
# print a
# ==============================
# type operator
# ============================
# a=100
# print type(a)
# # 
# j=10.00
# print type(j)
# # # 
# s="python"
# print type(s)


# s1='pyth'
# print type(s1)


# boo= True
# print type(boo)

# boo1= False
# print type(boo1)

# k='10'
# print type(k)

# boo2= "False"
# print type(boo2)


# # ctrl + /
# print type(a)
# # # # # print "type of j=10.0"
# print type(j)
# l=[1,2,3]
# print type(l)
# print type(s)
# print type(k)
# print type(boo1)
# print type(boo2)
# print type(boo)
# print type(s1)
# x='10.0'
# print type(x)
# ===================================
# id operator - it gives the address in memory
# a=10
# print id(a)
# j=11
# print id(j)
# k=10
# print id(k)
# l=11
# print id(l)

# ===============================
# Is operator-- If id is same for 2 variable it will return the true othewise false
# i=10
# print id(i)
# j=11
# l=10
# k=10.1
# m='10'
# print id(j)
# print i is j
# print id(l)
# print id(j)
# print i is l
# print i is k
# print i is m
# p="python"
# q="Python"
# r="python"
# print p is q
# print p is r
# ===================================
# == operator - numeric values are same or not
i=10
# print id(i)
j=10
# # print id(j)
k=10.1
l=10.0
m='10'
# print i ==j
# print i == l
# print i is l
# print i == k
# print i == m

s1="python"
s2="Python" # case sensitive
s3="Python" # case sensitive
# print s1 == s2
# print s3 == s2


# ===========================
##
# Swap values of a and b
# a=10
# b=200
# a=b  #a=100
# b=a  #b=100
# print a
# print b
# a=200
# b=10
# c = a           #c=10
# a = b             #a=100
# b = c            #b=10
# print a
# print b

# a=10
# b=200
# a=a+b    #a=10+200=210
# b=a-b    #b=210-200=10
# a=a-b    #a=210-10=200
# print a
# print b




# comma operator
# a,b=10,200
# print a
# print b

# print "value of a ", a
# print "value of b", b

# =========================

# a=10
# b=200
# a,b=b,a
# # 
# a,b= 200,10
# print a
# print b



# a,b=b,a

# a,b=b,a

# //Program
# print a #200
# print b #100

#############
#     +
# ---------------
# int  | int
# float|float
# int  |float
# float|int
# str  |str

# print 10+20
# print 10+20.0
# print 10.0+20.0
# print "Python"+" Scala"
# print "Python"+10
# print "Python"+'10'


#     *
# ---------------
# int  | int
# float|float
# int  |float
# float|int
# str  |int
# int  |str
# 
# 

# print 10*20
# print 10*20.0
# print 10.0*20.0
# print "python "*5
# print 5*"python "
# print '5'*"python"
# ======================================
# print 4%4
# print 5%4
# print 10%3
# print 3%10
# print 3333%1000000
# print 33%10
# print 10%2

# =========================================
# print 10**3
# print 2**2

# abs(x)
# print abs (-10)
# print abs (-10000)
# print abs (0.10)

# %d for integer
# %s for string
# %r for float

# st="python"
# st1="java"
# print "python" + " scala"
# print st + "    " +st1
# print st +st1
# 
# 
# print "Directory changed successfully " +st + " to the home directory"
# print "Directory changed successfully %s" %"java python"
# print "Directory %s changed successfully %s " %(st,st1)
# print "Directory changed %s successfully " %st
# print "Directory changed successfully " +st
# print "Directory changed %d successfully" %100
# intD=10.0
# print "Directory changed %r successfully" % intD


# Assignment
# 1) How a C program compiled?
# 2) How to run C program using command line .
# 3) C Program memory stucture..
# 4) How to swap 2 variable using XOR OR AND operator bitwise
# 5) how to run Java program using command line

